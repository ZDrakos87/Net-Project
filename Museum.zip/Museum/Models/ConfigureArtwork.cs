﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureArtwork : IEntityTypeConfiguration<Artwork>
    {
        public void Configure(EntityTypeBuilder<Artwork> entity)
        {
            
        }
    }
}





//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;

//namespace Museum.Models
//{
//    namespace Museum.Models
//    {
//        internal class ConfigureArtwork : IEntityTypeConfiguration<Artwork>
//        {
//            public void Configure(EntityTypeBuilder<Artwork> entity)
//            {
//                // remove cascading delete with Genre
//                entity.HasOne(b => b.Category)
//                    .WithMany(g => g.Artist)
//                    .OnDelete(DeleteBehavior.Restrict);

//                entity.HasData(
//                        new
//                        {
//                            ArtistId = 10087,
//                            Title = "Limestone Step Pyramid Foundation Tablet",
//                            YearCreated = "2660 BCE",
//                            Era = "Antiquity",
//                            EraId ="ANT00",
//                            Exhibit ="The Ancient Middle East",
//                            ExhibitId= "97582",
//                            ArrivalDate = "9/17/2024",
//                            DepartureDate = "4/5/2025",
//                        },
//                          new
//                          {
//                              ArtistId = 10088,
//                              Title = "Athena Parthenos Shield Fragment",
//                              YearCreated = "438 BCE",
//                              Era = "Antiquity",
//                              EraId = "ANT00",
//                              Exhibit = "Classical Greece and Rome",
//                              ExhibitId = "06873",
//                              ArrivalDate = "5/23/2022",
//                              DepartureDate = "11/12/2022",


//                            {
//                                  new
//                                  {
//                                      ArtistId = 10089,
//                                      Title = "Fine Wind, Clear Morning (a.k.a. Red Fuji)",
//                                      YearCreated = "1830-1832 CE",
//                                      Era = "Edo Period",
//                                      EraId = "ED1532",
//                                      Exhibit = "Land of the Rising Sun",
//                                      ExhibitId = "55263",
//                                      ArrivalDate = "3/8/2021",
//                                      DepartureDate = "6/15/2023",

//                              {
//                        new
//                        {
//                            ArtistId = 10090,
//                            Title = "Self-Portrait as the Allegory of Painting (La Pittura)",
//                            YearCreated = "1638-1639 CE",
//                            Era = "Renaissance",
//                            EraId = "REV8733",
//                            Exhibit = "Renaissance Wonders",
//                            ExhibitId = "06873",
//                            ArrivalDate = "5/15/2018",
//                            DepartureDate = "9/22/2019",

//                              {
//                            new
//                            {
//                            ArtistId = 10091,
//                            Title = "The Knight, Death, and the Devil (engraving)",
//                            YearCreated = "1513 CE",
//                            Era = "Renaissance",
//                            EraId = "REV8733",
//                            Exhibit = "Renaissance Wonders",
//                            ExhibitId = "06837",
//                            ArrivalDate = "8/11/2025",
//                            DepartureDate = "12/18/2025",
//                        }
//                                 new
//                                 {
//                                     ArtistId = 10092,
//                                     Title = "Self-Portrait with Thorn Necklace and Hummingbird\r\n",
//                                     YearCreated = "1940 CE",
//                                     Era = "Modernism",
//                                     EraId = "MD5568",
//                                     Exhibit = "Modern Marvels",
//                                     ExhibitId = "MM05538",
//                                     ArrivalDate = "2/4/2022",
//                                     DepartureDate = "5/19/2022",
//                                 }

//                        new
//                        {
//                            ArtistId = 10093,
//                            Title = "Pumpkin (Yellow with Black Dots)",
//                            YearCreated = "1994",
//                            Era = "Contemporary",
//                            Exhibit ="Works of Today",
//                            ExhibitId="WT077",
//                            ArrivalDate ="10/2/2023",
//                            DepartureDate = "8/13/2024",
//                        },
//                       new
//                        {
//                        ArtistId = 10094,
//                        Title = "Horn Players",
//                        YearCreated = "1994",
//                        Era = "Contemporary",
//                        Exhibit = "Works of Today",
//                        ExhibitId = "WT055",
//                        ArrivalDate = "4/21/2021",
//                        DepartureDate = "7/18/2022",
//                                      },

//                             new
//                             {
//                                 ArtistId = 10095,
//                                 Title = "The Musicians",
//                                 YearCreated = "1994",
//                                 Era = "Contemporary",
//                                 Exhibit = "Works of Today",
//                                 ExhibitId = "WT055",
//                                 ArrivalDate = "4/21/2021",
//                                 DepartureDate = "7/18/2022",
//                             },
//                                          new
//                                          {

//                                              ArtistId = 10096,
//                                              Title = "Primordial Chaos, No. 16",
//                                              YearCreated = "1906",
//                                              Era = "Modernism",
//                                              Exhibit = "Surreal and Abstract",
//                                              ExhibitId = "MD5568",
//                                              ArrivalDate = "7/25/2025",
//                                              DepartureDate = "7/18/2022",






//                             );
//            }
//        }
//    }
