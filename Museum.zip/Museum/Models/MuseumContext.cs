﻿using Microsoft.EntityFrameworkCore;

namespace Museum.Models
{
    public class MuseumContext : DbContext
    {
        public MuseumContext(DbContextOptions<MuseumContext> options)
            : base(options)
        {
        }

        public DbSet<Artist> Artist { get; set; } = null!;
        public DbSet<Artwork> Artwork { get; set; } = null!;
        public DbSet<Category> Category { get; set; } = null!;
        public DbSet<Ticket> Tickets { get; set; } = null!;
    }
}


//  [Range(1, 1000)]
//[Required(ErrorMessage = "Ticket is required.")]
//public int Ticket { get; set; }

//[Range(1, 10)]
//[Required(ErrorMessage = "Ticket id is required..")]
//public int TicketId { get; set; }

//[Range(0, 500)]
//[Required(ErrorMessage = "Price is required.")]
//public int Price { get; set; }

//[Range(1, 100)]
//[Required(ErrorMessage = "Quantity must be between 1 and 100.")]
//public int QuantityAvailable { get; set; }

//[Range(0.25, 10.5)]
//[Required(ErrorMessage = "Price must be between 0.25 and 10.5.")]
//public int PurchaseDate { get; set; }

//[Range(0.25, 10.5)]
//[Required(ErrorMessage = "Price must be between 0.25 and 10.5.")]
//public string User { get; set; } = String.Empty;


//[Range(0.25, 10.5)]
//[Required(ErrorMessage = "Price must be between 0.25 and 10.5.")]
//public int UserId { get; set; }



//[Range(0.25, 10.5)]
//[Required(ErrorMessage = "Price must be between 0.25 and 10.5.")]
//public string UserName { get; set; } = String.Empty;


//[StringLength(50)]
//[Required(ErrorMessage = "Email must be entered.")]
//public string Email { get; set; } = String.Empty;
//    }