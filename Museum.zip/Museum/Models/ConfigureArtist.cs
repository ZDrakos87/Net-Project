﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureArtist : IEntityTypeConfiguration<Artist>
    {
        public void Configure(EntityTypeBuilder<Artist> entity)
        {
            
        }
    }
}






//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;

//namespace Museum.Models
//{
//    internal class ConfigureArtist : IEntityTypeConfiguration<Artist>
//    {
//        public void Configure(EntityTypeBuilder<Artist> entity)
//        {
//            // remove cascading delete with Genre
//            entity.HasOne(b => b.Category)
//                .WithMany(g => g.Artwork)
//                .OnDelete(DeleteBehavior.Restrict);

//            entity.HasData(
//                    new { ArtistId = 10087,
//                        ArtistName = "Imhotep", 
//                        Nationality = "Egyptian",
//                        Biography="Celebrated architect, physician, and priest of the Old Kingdom. Although famous for the Step Pyramid, he also contributed to early Egyptian scientific and artistic traditions.",
//                    },
//                      new
//                      {
//                          ArtistId = 10088,
//                          ArtistName = "Phidias",
//                          Nationality = "Greek",
//                          Biography = "The preeminent sculptor of classical antiquity. Known for godlike proportions and mastery of marble and bronze.",
//                      }, new
//                      {
//                          ArtistId = 10089,
//                          ArtistName = "Katsushika Hokusai",
//                          Nationality = "Japanese",
//                          Biography = "One of the most influential ukiyo-e printmakers, whose works reshaped both Japanese and European art.",
//                      }, new
//                      {
//                          ArtistId = 10090,
//                          ArtistName = "Artemisia Gentileschi",
//                          Nationality = "Italian",
//                          Biography = "A powerful Baroque painter known for dramatic realism, chiaroscuro, and fierce female subjects.",
//                      }, new
//                      {
//                          ArtistId = 10091,
//                          ArtistName = "Albrecht Dürer",
//                          Nationality = "German",
//                          Biography = "Master engraver, painter, and mathematical theorist. His prints disseminated Renaissance ideas across Europe.",
//                      }, new
//                      {
//                          ArtistId = 10092,
//                          ArtistName = "Frida Kahlo",
//                          Nationality = "Mexican",
//                          Biography = "Iconic painter whose symbolic self-portraits explore pain, identity, and cultural mythology",
//                      }, new
//                      {
//                          ArtistId = 10093,
//                          ArtistName = "Yayoi Kusama",
//                          Nationality = "Japanese",
//                          Biography = "Avant-garde visionary known for polka dots, infinity motifs, and psychological–cosmic symbolism.",
//                      }, new
//                      {
//                          ArtistId = 10094,
//                          ArtistName = "Jean-Michel Basquiat",
//                          Nationality = "American",
//                          Biography = "A prodigy who rose from graffiti to high art, blending symbolism, anatomy, and commentary on race and power.",
//                      }, new
//                      {
//                          ArtistId = 10095,
//                          ArtistName = "Caravaggio (Michelangelo Merisi da Caravaggio)",
//                          Nationality = "Italian",
//                          Biography = "Known for visceral realism and dramatic contrast, Caravaggio shaped European painting for centuries.",
//                      }, new
//                      {
//                          ArtistId = 10096,
//                          ArtistName = "Hilma af Klint",
//                          Nationality = "Swedish",
//                          Biography = "A mystic and pioneer of abstraction whose visionary works were decades ahead of their time.",
//                         );
//        }
//}
//}
