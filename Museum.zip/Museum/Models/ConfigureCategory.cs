﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureCategory : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> entity)
        {
            // TODO: Add HasData() or any configuration for Category later.
        }
    }
}





//using Microsoft.EntityFrameworkCore.Metadata.Builders;
//using Microsoft.EntityFrameworkCore;
//using System.ComponentModel.DataAnnotations;

//namespace Museum.Models
//{
//    namespace BookstoreDataExample.Models
//    {
//        public class ConfigureGenres : IEntityTypeConfiguration<Category>
//        {
//            public void Configure(EntityTypeBuilder<Category> entity)
//            {
//                // seed initial data
//                entity.HasData(
//                    new {

//                    Work = "Limestone Step Pyramid Foundation Tablet",
//                    CategoryId = "Ancient Artifact",
//                    CategoryName = "CAT_AA01",

//                    },
//                    new
//                    {
//                        Work = "Athena Parthenos Shield Fragment (Reconstruction Panel)\r\n",
//                        CategoryId = "Classical Relief Sculpture",
//                        CategoryName = "CAT_CRS02",
//                    },
//                     new
//                     {
//                         Work = "Fine Wind, Clear Morning (Red Fuji)\r\n",
//                         CategoryId = "Woodblock Print",
//                         CategoryName = "CAT_WBP03",
//                     },
//                      new
//                      {
//                          Work = "Self-Portrait as the Allegory of Painting\r\n",
//                          CategoryId = "Oil Painting",
//                          CategoryName = "CAT_OP04",
//                      },
//                      new
//                      {
//                          Work = "The Knight, Death, and the Devil\r\n",
//                          CategoryId = "Engraving",
//                          CategoryName = "CAT_ENG05",
//                      },

//                      new
//                      {
//                          Work = "Self-Portrait with Thorn Necklace and Hummingbird\r\n",
//                          CategoryId = "Oil Painting",
//                          CategoryName = "CAT_OP06",
//                      },
//                        new
//                        {
//                            Work = "Pumpkin (Yellow with Black Dots)\r\n",
//                            CategoryId = "Contemporary Sculpture",
//                            CategoryName = "CAT_CS07",
//                        },
//                        new
//                        {
//                            Work = "Horn Players\r\n",
//                            CategoryId = "Acrylic & Oil on Canvas (Mixed Media Painting)",
//                            CategoryName = "CAT_MMP08",
//                        },
//                        new
//                        {
//                            Work = "The Musicians\r\n",
//                            CategoryId = "Oil Painting",
//                            CategoryName = "CAT_OP09",
//                        },
//                        new
//                        {
//                            Work = "Primordial Chaos No. 16\r\n",
//                            CategoryId = "Abstract Work",
//                            CategoryName = "CAT_ABS10",
//                        }


//            }
//        }
//    }
