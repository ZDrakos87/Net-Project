﻿namespace Museum.Models
{
    public class Artwork
    {
        public int ArtworkId { get; set; }      // PRIMARY KEY ✅

        public int ArtistId { get; set; }
        public string ArtistName { get; set; } = null!;
        public string Nationality { get; set; } = null!;
        public string Biography { get; set; } = null!;
        public string Title { get; set; } = null!;
        public string YearCreated { get; set; } = null!;
        public string Era { get; set; } = null!;
        public string EraId { get; set; } = null!;
        public string Exhibit { get; set; } = null!;
        public string ExhibitId { get; set; } = null!;
        public string CategoryName { get; set; } = null!;
        public string CategoryId { get; set; } = null!;
        public string ArrivalDate { get; set; } = null!;
        public string DepartureDate { get; set; } = null!;
    }
}
