﻿using System.ComponentModel.DataAnnotations;

namespace Museum.Models
{
    public class Artist
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100)]
        public string ArtistName { get; set; } = string.Empty;



        [Range(1, 10)]
        [Required(ErrorMessage = "Must be between 1 and 10")]
        public int ArtistId { get; set; }

        [Required(ErrorMessage = "Nationality is required.")]
        [StringLength(100)]
        public string Nationality { get; set; } = String.Empty;


        [Required(ErrorMessage = "Biography is required.")]
        [StringLength(400)]
        public string Biography { get; set; } = String.Empty;
    }
}
