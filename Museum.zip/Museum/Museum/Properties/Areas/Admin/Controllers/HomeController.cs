﻿using Microsoft.AspNetCore.Mvc;

namespace Museum.Properties.Areas.Admin.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
