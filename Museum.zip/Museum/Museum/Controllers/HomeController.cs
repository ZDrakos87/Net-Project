using System.ComponentModel;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Museum.Models;

namespace MuseumControllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();


        }
    }
}
