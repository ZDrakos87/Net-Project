﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Museum.Models;
using System;
using System.Linq;

namespace Museum.Controllers
{
    public class MuseumController : Controller
    {
        private readonly MuseumContext _context;

        public MuseumController(MuseumContext context)
        {
            _context = context;
        }

        // GET: /Museum
        public IActionResult Index()
        {
            // Later you can Include Artist / Category:
            // var artworks = _context.Artwork.Include(a => a.Artist).Include(a => a.Category).ToList();
            var artworks = _context.Artwork.ToList();
            return View(artworks);
        }

        // Helper to populate dropdowns
        private void LoadDropdowns()
        {
            ViewBag.Artists = _context.Artist
                .OrderBy(a => a.ArtistName)
                .ToList();

            ViewBag.Categories = _context.Category
                .OrderBy(c => c.CategoryName)
                .ToList();
        }

        // GET: /Museum/Add
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            LoadDropdowns();
            return View("Edit", new Artwork());
        }

        // GET: /Museum/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            LoadDropdowns();

            var artwork = _context.Artwork.Find(id);
            if (artwork == null)
                return NotFound();

            return View(artwork);
        }

        // POST: /Museum/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Artwork artwork)
        {
            if (ModelState.IsValid)
            {
                // Use ArtworkId to decide if this is a new record
                if (artwork.ArtworkId == 0)
                {
                    _context.Artwork.Add(artwork);
                }
                else
                {
                    _context.Artwork.Update(artwork);
                }

                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Action = (artwork.ArtworkId == 0) ? "Add" : "Edit";
            LoadDropdowns();
            return View(artwork);
        }

        // GET: /Museum/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var artwork = _context.Artwork.Find(id);
            if (artwork == null)
                return NotFound();

            return View(artwork);
        }

        // POST: /Museum/Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(Artwork artwork)
        {
            _context.Artwork.Remove(artwork);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // POST: /Museum/BuyTicket
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult BuyTicket(int artworkId, int quantity)
        {
            var artwork = _context.Artwork.Find(artworkId);
            if (artwork == null)
                return NotFound();

            var random = new Random();
            int numericTicketId;

            do
            {
                numericTicketId = random.Next(100000, 999999);
            }
            while (_context.Tickets.Any(t => t.TicketId == numericTicketId.ToString()));

            var ticket = new Ticket
            {
                TicketId = numericTicketId.ToString(),
                Price = 5.00m,
                QuantityAvailable = quantity,
                PurchaseDate = DateTime.Now,
                UserId = "temp-user",
                UserName = "temp-user",
                UserEmail = ""
            };

            _context.Tickets.Add(ticket);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }
    }
}
