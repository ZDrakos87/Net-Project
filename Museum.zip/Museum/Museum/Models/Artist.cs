﻿namespace Museum.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }              // PK
        public string ArtistName { get; set; } = null!;
        public string Nationality { get; set; } = null!;
        public string Biography { get; set; } = null!;

        // 1-1: one Artist <-> one Artwork
        public Artwork? Artwork { get; set; }

        // Many-to-many: Artist <-> Category
        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }
}
