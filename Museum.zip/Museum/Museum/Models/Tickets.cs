﻿using System.ComponentModel.DataAnnotations;

namespace Museum.Models
{
    public class Ticket
    {
        public string TicketId { get; set; } = null!;       // PK
        public decimal Price { get; set; }
        public int QuantityAvailable { get; set; } // total remaining
        public DateTime PurchaseDate { get; set; }

        public string UserId { get; set; } = null!; // FK to user
        public string UserName { get; set; } = null!;

        public string UserEmail { get; set; } = null!;
    }
}