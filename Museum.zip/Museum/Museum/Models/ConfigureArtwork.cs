﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureArtwork : IEntityTypeConfiguration<Artwork>
    {
        public void Configure(EntityTypeBuilder<Artwork> entity)
        {
            entity.HasData(
                new
                {
                    ArtworkId = 1,
                    ArtistId = 10087,
                    ArtistName = "Imhotep",
                    Title = "Limestone Step Pyramid Foundation Tablet",
                    YearCreated = "2660 BCE",
                    CategoryId = 1,
                    CategoryName = "Ancient Artifact",
                    Era = "Antiquity",
                    EraId = "ANT00",
                    Exhibit = "The Ancient Middle East",
                    ExhibitId = "97582",
                    ArrivalDate = "9/17/2024",
                    DepartureDate = "4/5/2025"
                },
                new
                {
                    ArtworkId = 2,
                    ArtistId = 10088,
                    ArtistName = "Phidias",
                    Title = "Athena Parthenos Shield Fragment",
                    CategoryId = 2,
                    CategoryName = "Classical Relief Sculpture",
                    YearCreated = "438 BCE",
                    Era = "Antiquity",
                    EraId = "ANT00",
                    Exhibit = "Classical Greece and Rome",
                    ExhibitId = "06873",
                    ArrivalDate = "5/23/2022",
                    DepartureDate = "11/12/2022"
                },
                new
                {
                    ArtworkId = 3,
                    ArtistId = 10089,
                    ArtistName = "Katsushika Hokusai",
                    Title = "Fine Wind, Clear Morning (a.k.a. Red Fuji)",
                    CategoryId = 3,
                    CategoryName = "Woodblock Print",
                    YearCreated = "1830-1832 CE",
                    Era = "Edo Period",
                    EraId = "ED1532",
                    Exhibit = "Land of the Rising Sun",
                    ExhibitId = "55263",
                    ArrivalDate = "3/8/2021",
                    DepartureDate = "6/15/2023"
                },
                new
                {
                    ArtworkId = 4,
                    ArtistId = 10090,
                    ArtistName = "Artemisia Gentileschi",
                    Title = "Self-Portrait as the Allegory of Painting (La Pittura)",
                    YearCreated = "1638-1639 CE",
                    CategoryId = 4,
                    CategoryName = "Oil Painting",
                    Era = "Renaissance",
                    EraId = "REV8733",
                    Exhibit = "Renaissance Wonders",
                    ExhibitId = "06873",
                    ArrivalDate = "5/15/2018",
                    DepartureDate = "9/22/2019"
                },
                new
                {
                    ArtworkId = 5,
                    ArtistId = 10091,
                    ArtistName = "Albrecht Dürer",
                    Title = "The Knight, Death, and the Devil (engraving)",
                    CategoryId = 5,
                    CategoryName = "Engraving",
                    YearCreated = "1513 CE",
                    Era = "Renaissance",
                    EraId = "REV8733",
                    Exhibit = "Renaissance Wonders",
                    ExhibitId = "06837",
                    ArrivalDate = "8/11/2025",
                    DepartureDate = "12/18/2025"
                },
                new
                {
                    ArtworkId = 6,
                    ArtistId = 10092,
                    ArtistName = "Frida Kahlo",
                    Title = "Self-Portrait with Thorn Necklace and Hummingbird",
                    CategoryId = 6,
                    CategoryName = "Oil Painting (Portrait)",
                    YearCreated = "1940 CE",
                    Era = "Modernism",
                    EraId = "MD5568",
                    Exhibit = "Modern Marvels",
                    ExhibitId = "MM05538",
                    ArrivalDate = "2/4/2022",
                    DepartureDate = "5/19/2022"
                },
                new
                {
                    ArtworkId = 7,
                    ArtistId = 10093,
                    ArtistName = "Yayoi Kusama",
                    Title = "Pumpkin (Yellow with Black Dots)",
                    CategoryId = 7,
                    CategoryName = "Contemporary Sculpture",
                    YearCreated = "1994",
                    Era = "Contemporary",
                    EraId = "CONT01",
                    Exhibit = "Works of Today",
                    ExhibitId = "WT077",
                    ArrivalDate = "10/2/2023",
                    DepartureDate = "8/13/2024"
                },
                new
                {
                    ArtworkId = 8,
                    ArtistId = 10094,
                    ArtistName = "Jean-Michel Basquiat",
                    Title = "Horn Players",
                    CategoryId = 8,
                    CategoryName = "Mixed Media Painting",
                    YearCreated = "1983",
                    Era = "Contemporary",
                    EraId = "CONT01",
                    Exhibit = "Works of Today",
                    ExhibitId = "WT055",
                    ArrivalDate = "4/21/2021",
                    DepartureDate = "7/18/2022"
                },
                new
                {
                    ArtworkId = 9,
                    ArtistId = 10095,
                    ArtistName = "Caravaggio (Michelangelo Merisi da Caravaggio)",
                    Title = "The Musicians",
                    CategoryId = 9,
                    CategoryName = "Baroque Oil Painting",
                    YearCreated = "1595",
                    Era = "Baroque",
                    EraId = "BAR001",
                    Exhibit = "Works of Today",
                    ExhibitId = "WT055",
                    ArrivalDate = "4/21/2021",
                    DepartureDate = "7/18/2022"
                },
                new
                {
                    ArtworkId = 10,
                    ArtistId = 10096,
                    ArtistName = "Hilma af Klint",
                    Title = "Primordial Chaos, No. 16",
                    CategoryId = 10,
                    CategoryName = "Abstract Work",
                    YearCreated = "1906",
                    Era = "Modernism",
                    EraId = "MD5568",
                    Exhibit = "Surreal and Abstract",
                    ExhibitId = "MD5568",
                    ArrivalDate = "7/25/2025",
                    DepartureDate = "7/18/2026"
                }
            );
        }
    }
}
