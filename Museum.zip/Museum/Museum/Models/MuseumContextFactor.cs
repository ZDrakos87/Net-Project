﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Museum.Models
{
   
    public class MuseumContextFactory : IDesignTimeDbContextFactory<MuseumContext>
    {
        public MuseumContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<MuseumContext>();

            
            optionsBuilder.UseSqlServer(
                "Server=(localdb)\\MSSQLLocalDB;Database=Museum;Trusted_Connection=True;MultipleActiveResultSets=true"
            );

            return new MuseumContext(optionsBuilder.Options);
        }
    }
}
