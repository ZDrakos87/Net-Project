﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureCategory : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> entity)
        {
            entity.HasData(
                new Category { CategoryId = 1, CategoryName = "Ancient Artifact" },
                new Category { CategoryId = 2, CategoryName = "Classical Relief Sculpture" },
                new Category { CategoryId = 3, CategoryName = "Woodblock Print" },
                new Category { CategoryId = 4, CategoryName = "Oil Painting" },
                new Category { CategoryId = 5, CategoryName = "Engraving" },
                new Category { CategoryId = 6, CategoryName = "Oil Painting (Portrait)" },
                new Category { CategoryId = 7, CategoryName = "Contemporary Sculpture" },
                new Category { CategoryId = 8, CategoryName = "Mixed Media Painting" },
                new Category { CategoryId = 9, CategoryName = "Baroque Oil Painting" },
                new Category { CategoryId = 10, CategoryName = "Abstract Work" }
            );
        }
    }
}
