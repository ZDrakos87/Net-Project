﻿namespace Museum.Models
{
    public class Category
    {
        public int CategoryId { get; set; }            // PK
        public string CategoryName { get; set; } = null!;

        // Many-to-many: Category <-> Artist
        public ICollection<Artist> Artists { get; set; } = new List<Artist>();
    }
}
