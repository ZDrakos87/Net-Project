﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Museum.Models
{
    public class ConfigureTickets : IEntityTypeConfiguration<Ticket>
    {
        public void Configure(EntityTypeBuilder<Ticket> entity)
        {
            // Explicit precision for money: decimal(18, 2)
            entity.Property(t => t.Price)
                  .HasColumnType("decimal(18,2)");

            entity.HasData(
                new Ticket
                {
                    TicketId = "56789",
                    Price = 5.00m,
                    QuantityAvailable = 400,
                    PurchaseDate = new DateTime(2024, 1, 1),
                    UserId = "user-123",
                    UserName = "user-123",
                    UserEmail = ""
                }
            );
        }
    }
}
