﻿namespace Museum.Models
{
    public class Artwork
    {
        public int ArtworkId { get; set; }             // PK

        // FK to Artist
        public int ArtistId { get; set; }
        public Artist Artist { get; set; } = null!;    // navigation

        public string ArtistName { get; set; } = null!;
        public string Title { get; set; } = null!;
        public string YearCreated { get; set; } = null!;
        public string Era { get; set; } = null!;
        public string EraId { get; set; } = null!;
        public string Exhibit { get; set; } = null!;
        public string ExhibitId { get; set; } = null!;
        public string CategoryName { get; set; } = null!;
        public int CategoryId { get; set; } 
        public string ArrivalDate { get; set; } = null!;
        public string DepartureDate { get; set; } = null!;
    }
}
