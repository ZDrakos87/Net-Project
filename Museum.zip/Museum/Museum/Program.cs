using Microsoft.EntityFrameworkCore;
using Museum.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// THIS MUST MATCH THE KEY IN appsettings.json ("MuseumContext")
builder.Services.AddDbContext<MuseumContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("MuseumContext")));

var app = builder.Build();

app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Museum}/{action=Index}/{id?}");

app.Run();
